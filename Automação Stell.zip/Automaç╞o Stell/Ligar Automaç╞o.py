from ast import Try
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from time import sleep

driver = webdriver.Chrome()
options = webdriver.ChromeOptions()
options.add_extension('adblock.crx')
driver = webdriver.Chrome(options=options)

driver.get('https://youtube.com/channel/UC1a3h09g_djN94d2X_kvsAA')
driver.maximize_window()
sleep(3)
driver.switch_to.window(driver.window_handles[1])
driver.close()
driver.switch_to.window(driver.window_handles[0])

for c in range(1,6):
    #WebDriverWait(driver, 300).until(EC.presence_of_element_located((By.CSS_SELECTOR, '#tabsContent > tp-yt-paper-tab:nth-child(4)')))
    #driver.find_element(By.CSS_SELECTOR, '#tabsContent > tp-yt-paper-tab:nth-child(4)').click()
    WebDriverWait(driver, 300).until(EC.presence_of_element_located((By.XPATH, f'//*[@id="items"]/ytd-grid-video-renderer[{c}]')))
    driver.find_element(By.XPATH, f'//*[@id="items"]/ytd-grid-video-renderer[{c}]').click()
    sleep(2)
    try:
        duracao = driver.find_element(By.CSS_SELECTOR, '#movie_player > div.ytp-chrome-bottom > div.ytp-chrome-controls > div.ytp-left-controls > div.ytp-time-display.notranslate > span:nth-child(2) > span.ytp-time-duration').text
    except:
        sleep(2)
    else:
        duracaosplit = duracao.split(':')
        tempo = (int(duracaosplit[0])*60) + int(duracaosplit[1])
        sleep(tempo)
    driver.execute_script("window.open('https://youtube.com/channel/UC1a3h09g_djN94d2X_kvsAA');")
    driver.close()
    driver.switch_to.window(driver.window_handles[0])
    #driver.execute_script('document.getElementsByTagName("video")[0].playbackRate = 5')
    
